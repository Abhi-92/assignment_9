#!/usr/bin/python -tt
#from __future__ import division
import sys

def main():

	mood = [[0 for x in xrange(7)] for x in xrange(7)]
	now=0
	e1=":)"
	e2=":D"
	e3=":("
	e4=":'("
	e5=":P"
	e6=";)"
	e7=":-o"
	e8="O_O"
	e9="B-)"
	e10=";)"
	e11=":-/"
	e12="=_="
	e13="x-("
	e14=">_<"

	f = open("content.txt",'r')
	op = open("ouput.txt",'w')

	for line in f:
		user=line[:1]
		if user == 'A':
			n=0
		elif user == 'B':
			n=1
		elif user == 'C':
			n=2
		elif user == 'D':
			n=3
		elif user == 'E':
			n=4
		elif user == 'F':
			n=5
		elif user == 'G':
			n=6

		if e1 in line or e2 in line:
			mood[n][0]=mood[n][0]+1

		elif e3 in line or e4 in line:
			mood[n][1]=mood[n][1]+1

		elif e5 in line or e6 in line:
			mood[n][2]=mood[n][2]+1

		elif e7 in line or e8 in line:
			mood[n][3]=mood[n][3]+1

		elif e9 in line or e10 in line:
			mood[n][4]=mood[n][4]+1

		elif e11 in line or e12 in line:
			mood[n][5]=mood[n][5]+1

		elif e13 in line or e14 in line:
			mood[n][6]=mood[n][6]+1

	
	mylist = [mood[0][0], mood[0][1],mood[0][2],mood[0][3],mood[0][4],mood[0][5],mood[0][6]]

	maximum=0
	for index,value in enumerate(mylist):
    		if value>=maximum:
        		maximum=value
       			m=index

	if m==0:
		op.write("user_A : Happy")
	elif m==1:
		op.write("user_A : Sad")
	elif m==2:
		op.write("user_A : Sarcastic")
	elif m==3:
		op.write("user_A : Surprised")
	elif m==4:
		op.write("user_A : Crook")
	elif m==5:
		op.write("user_A : Neutral")
	elif m==6:
		op.write("user_A : Angry")
	op.write('\n')

	mylist = [mood[1][0], mood[1][1],mood[1][2],mood[1][3],mood[1][4],mood[1][5],mood[1][6]]

	maximum=0
	for index,value in enumerate(mylist):
    		if value>maximum:
        		maximum=value
       			m=index

	if m==0:
		op.write("user_B : Happy")
	elif m==1:
		op.write("user_B : Sad")
	elif m==2:
		op.write("user_B : Sarcastic")
	elif m==3:
		op.write("user_B : Surprised")
	elif m==4:
		op.write("user_B : Crook")
	elif m==5:
		op.write("user_B : Neutral")
	elif m==6:
		op.write("user_B : Angry")
	op.write('\n')

	mylist = [mood[2][0], mood[2][1],mood[2][2],mood[2][3],mood[2][4],mood[2][5],mood[2][6]]

	maximum=0
	for index,value in enumerate(mylist):
    		if value>maximum:
        		maximum=value
       			m=index

	if m==0:
		op.write("user_C : Happy")
	elif m==1:
		op.write("user_C : Sad")
	elif m==2:
		op.write("user_C : Sarcastic")
	elif m==3:
		op.write("user_C : Surprised")
	elif m==4:
		op.write("user_C : Crook")
	elif m==5:
		op.write("user_C : Neutral")
	elif m==6:
		op.write("user_C : Angry")
	op.write('\n')

	mylist = [mood[3][0], mood[3][1],mood[3][2],mood[3][3],mood[3][4],mood[3][5],mood[3][6]]

	maximum=0
	for index,value in enumerate(mylist):
    		if value>maximum:
        		maximum=value
       			m=index

	if m==0:
		op.write("user_D : Happy")
	elif m==1:
		op.write("user_D : Sad")
	elif m==2:
		op.write("user_D : Sarcastic")
	elif m==3:
		op.write("user_D : Surprised")
	elif m==4:
		op.write("user_D : Crook")
	elif m==5:
		op.write("user_D : Neutral")
	elif m==6:
		op.write("user_D : Angry")
	op.write('\n')

	mylist = [mood[4][0], mood[4][1],mood[4][2],mood[4][3],mood[4][4],mood[4][5],mood[4][6]]

	maximum=0
	for index,value in enumerate(mylist):
    		if value>maximum:
        		maximum=value
       			m=index

	if m==0:
		op.write("user_E : Happy")
	elif m==1:
		op.write("user_E : Sad")
	elif m==2:
		op.write("user_E : Sarcastic")
	elif m==3:
		op.write("user_E : Surprised")
	elif m==4:
		op.write("user_E : Crook")
	elif m==5:
		op.write("user_E : Neutral")
	elif m==6:
		op.write("user_E : Angry")
	op.write('\n')

	mylist = [mood[5][0], mood[5][1],mood[5][2],mood[5][3],mood[5][4],mood[5][5],mood[5][6]]

	maximum=0
	for index,value in enumerate(mylist):
    		if value>maximum:
        		maximum=value
       			m=index

	if m==0:
		op.write("user_F : Happy")
	elif m==1:
		op.write("user_F : Sad")
	elif m==2:
		op.write("user_F : Sarcastic")
	elif m==3:
		op.write("user_F : Surprised")
	elif m==4:
		op.write("user_F : Crook")
	elif m==5:
		op.write("user_F : Neutral")
	elif m==6:
		op.write("user_F : Angry")
	op.write('\n')

	mylist = [mood[6][0], mood[6][1],mood[6][2],mood[6][3],mood[6][4],mood[6][5],mood[6][6]]

	maximum=0
	for index,value in enumerate(mylist):
    		if value>maximum:
        		maximum=value
       			m=index

	if m==0:
		op.write("user_G : Happy")
	elif m==1:
		op.write("user_G : Sad")
	elif m==2:
		op.write("user_G : Sarcastic")
	elif m==3:
		op.write("user_G : Surprised")
	elif m==4:
		op.write("user_G : Crook")
	elif m==5:
		op.write("user_G : Neutral")
	elif m==6:
		op.write("user_G : Angry")
	op.write('\n')
	noe=0
	x=0
	y=0	
	z=7
	count=[0,0,0,0,0,0,0]
	while (x<z):
		while (y<z):
			noe += mood[x][y]
			count[x] += mood[y][x]			
			y=y+1
		x=x+1
		y=0

	op.write('-----------------------------------------------------------')
	op.write('\n')
	op.write('Mood_1 : '+str(+count[0]/float(noe))+'%')
	op.write('\n')
	op.write('Mood_2 : '+str(+count[1]/float(noe))+'%')
	op.write('\n')
	op.write('Mood_3 : '+str(+count[2]/float(noe))+'%')
	op.write('\n')
	op.write('Mood_4 : '+str(+count[3]/float(noe))+'%')
	op.write('\n')
	op.write('Mood_5 : '+str(+count[4]/float(noe))+'%')
	op.write('\n')
	op.write('Mood_6 : '+str(+count[5]/float(noe))+'%')
	op.write('\n')
	op.write('Mood_7 : '+str(+count[6]/float(noe))+'%')
	op.write('\n')
	op.close()
	f.close()
main()
